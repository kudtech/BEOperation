from django.apps import AppConfig


class BewebConfig(AppConfig):
    name = 'beweb'
