STATUS = (
    (1, ("Not relevant")),
    (2, ("Review")),
    (3, ("Maybe relevant")),

)
